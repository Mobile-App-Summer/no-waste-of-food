package com.fbip.discussion_board

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
